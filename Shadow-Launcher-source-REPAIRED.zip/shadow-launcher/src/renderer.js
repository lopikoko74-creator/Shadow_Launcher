const $ = (id) => document.getElementById(id);
const toast = (message) => {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(window.__toastTimer); window.__toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
};
const pages = ["home","versions","mods","library","settings"];
function showPage(id) {
  pages.forEach(p => $(p).classList.toggle("active", p === id));
  document.querySelectorAll(".nav[data-page]").forEach(b => b.classList.toggle("active", b.dataset.page === id));
  $("pageName").textContent = ({home:"ГЛАВНАЯ",versions:"ВЕРСИИ ИГРЫ",mods:"КАТАЛОГ МОДОВ",library:"БИБЛИОТЕКА",settings:"НАСТРОЙКИ"})[id];
}
document.querySelectorAll(".nav[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.go)));
document.querySelectorAll(".client-card").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll(".client-card").forEach(x => x.classList.remove("chosen"));
  b.classList.add("chosen");
  const rust = b.dataset.client === "rust";
  $("selectedClient").textContent = rust ? "Rust-клиент" : "Java Edition";
  toast(rust ? "Выбран Rust-клиент. Сначала требуется определить поддерживаемый проект." : "Выбрана Java Edition.");
  document.querySelectorAll(".select-label").forEach(x => x.textContent = "ВЫБРАТЬ");
  b.querySelector(".select-label").textContent = "ВЫБРАНО ✓";
}));
async function refreshProfiles() {
  try {
    const names = await window.shadow.listProfiles();
    $("profileCount").textContent = `${names.length} профилей`;
    $("profiles").innerHTML = "";
    if (!names.length) $("profiles").innerHTML = '<div class="empty-state">Пока нет профилей. Создай первый профиль выше.</div>';
    names.forEach(name => {
      const item = document.createElement("div"); item.className = "profile-item";
      const label = document.createElement("span"); label.textContent = name;
      const pill = document.createElement("i"); pill.className = "pill"; pill.textContent = "ЛОКАЛЬНЫЙ ПРОФИЛЬ";
      item.append(label,pill); $("profiles").append(item);
    });
  } catch (e) { toast(e.message); }
}
$("createProfile").addEventListener("click", async () => {
  try {
    const result = await window.shadow.createProfile($("profileName").value);
    $("profileName").value = ""; await refreshProfiles(); toast(`Профиль «${result.name}» создан.`);
  } catch (e) { toast(e.message); }
});
$("profileName").addEventListener("keydown", e => { if (e.key === "Enter") $("createProfile").click(); });
$("quickPlay").addEventListener("click", () => { showPage("versions"); toast("Сначала выбери клиент и установи его компоненты."); });
$("searchMods").addEventListener("click", () => toast("API каталога будет подключён после выбора источников и фильтров совместимости."));
(async () => {
  try {
    const info = await window.shadow.appInfo();
    $("dataPath").textContent = info.userData;
    await refreshProfiles();
  } catch (e) { toast("Не удалось загрузить данные приложения: " + e.message); }
})();