const { app, BrowserWindow, ipcMain, shell } = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");

const isDev = !app.isPackaged;
const userData = app.getPath("userData");
const profilesDir = path.join(userData, "profiles");

function ensureDirs() {
  fs.mkdirSync(profilesDir, { recursive: true });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 980,
    minHeight: 680,
    backgroundColor: "#080910",
    title: "Shadow Launcher",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, "index.html"));
}

app.whenReady().then(() => {
  ensureDirs();
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

ipcMain.handle("app:info", () => ({
  version: app.getVersion(),
  platform: process.platform,
  arch: process.arch,
  home: os.homedir(),
  userData
}));

ipcMain.handle("profiles:list", () => {
  ensureDirs();
  return fs.readdirSync(profilesDir, { withFileTypes: true })
    .filter(x => x.isDirectory())
    .map(x => x.name);
});

ipcMain.handle("profiles:create", (_event, name) => {
  if (typeof name !== "string" || !/^[\w -]{1,40}$/.test(name.trim())) {
    throw new Error("Use 1–40 letters, numbers, spaces, _ or -.");
  }
  const safe = name.trim();
  const dir = path.join(profilesDir, safe);
  fs.mkdirSync(dir, { recursive: true });
  return { name: safe, path: dir };
});

ipcMain.handle("external:open", async (_event, url) => {
  const parsed = new URL(url);
  if (!["https:"].includes(parsed.protocol)) throw new Error("Only HTTPS links are allowed.");
  await shell.openExternal(parsed.toString());
  return true;
});

// Game installation and launch are intentionally not wired to an unverified
// Rust client or a guessed authentication flow. See README for integration plan.
ipcMain.handle("game:status", () => ({
  java: "not-installed",
  rust: "not-configured",
  note: "Choose a supported Rust client before enabling its installer."
}));
