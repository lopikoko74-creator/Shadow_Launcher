const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("shadow", {
  appInfo: () => ipcRenderer.invoke("app:info"),
  listProfiles: () => ipcRenderer.invoke("profiles:list"),
  createProfile: (name) => ipcRenderer.invoke("profiles:create", name),
  openExternal: (url) => ipcRenderer.invoke("external:open", url),
  gameStatus: () => ipcRenderer.invoke("game:status")
});
